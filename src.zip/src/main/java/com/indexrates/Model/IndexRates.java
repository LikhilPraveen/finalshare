package com.indexrates.Model;;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;


@Entity
@Table(name = "index_rate")
public class IndexRates {

    @Id
    private String rate_ticker;
    private String rate_type;
    private float rate;
    @JsonFormat(pattern="yyyy-MM-dd")
    private Date postdt;
    private String applid;
    private String entity;
    @JsonFormat(pattern="yyyy-MM-dd")
    private Date createdt;
    @JsonFormat(pattern="yyyy-MM-dd")
    private Date updatedt;
    private String ccy_code;
    @JsonFormat(pattern="yyyy-MM-dd")
    private Date rate_refresh_date;
    private String rate_ticker_desc;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date create_ts;
    private String created_by;

    public IndexRates() {

    }

    public IndexRates(String rate_ticker,String rate_type,float rate,
                      Date postdt,String applid, String entity, Date createdt,
                      Date updatedt, String ccy_code,Date rate_refresh_date,
                      String rate_ticker_desc,Date create_ts, String created_by) {
        this.rate_ticker = rate_ticker;
        this.rate_type = rate_type;
        this.rate =rate;
        this.postdt=postdt;
        this.applid = applid;
        this.entity = entity;
        this.createdt = createdt;
        this.updatedt = updatedt;
        this.ccy_code =ccy_code;
        this.rate_refresh_date=rate_refresh_date;
        this.rate_ticker_desc=rate_ticker_desc;
        this.create_ts=create_ts;
        this.created_by=created_by;
    }

    public String getRate_ticker() {
        return rate_ticker;
    }

    public void setRate_ticker(String rate_ticker) {
        this.rate_ticker = rate_ticker;
    }

    public String getRate_type() {
        return rate_type;
    }

    public void setRate_type(String rate_type) {
        this.rate_type = rate_type;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }

    public Date getPostdt() {
        return postdt;
    }

    public void setPostdt(Date postdt) {
        this.postdt = postdt;
    }

    public String getApplid() {
        return applid;
    }

    public void setApplid(String applid) {
        this.applid = applid;
    }

    public String getEntity() {
        return entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }

    public Date getCreatedt() {
        return createdt;
    }

    public void setCreatedt(Date createdt) {
        this.createdt = createdt;
    }

    public Date getUpdatedt() {
        return updatedt;
    }

    public void setUpdatedt(Date updatedt) {
        this.updatedt = updatedt;
    }

    public String getCcy_code() {
        return ccy_code;
    }

    public void setCcy_code(String ccy_code) {
        this.ccy_code = ccy_code;
    }

    public Date getRate_refresh_date() {
        return rate_refresh_date;
    }

    public void setRate_refresh_date(Date rate_refresh_date) {
        this.rate_refresh_date = rate_refresh_date;
    }

    public String getRate_ticker_desc() {
        return rate_ticker_desc;
    }

    public void setRate_ticker_desc(String rate_ticker_desc) {
        this.rate_ticker_desc = rate_ticker_desc;
    }

    public Date getCreate_ts() {
        return create_ts;
    }

    public void setCreate_ts(Date create_ts) {
        this.create_ts = create_ts;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    @Override
    public String toString() {
        return "Index-Rate [rate_ticker=" + rate_ticker + ", " +
                "rate_type=" + rate_type + ",rate=" + rate + ", " +
                "postdt=" + postdt + ", applid=" + applid + "," +
                "entity=" + entity + ", createdt=" + createdt + ", " +
                "updatedt=" + updatedt + ", ccy_code=" + ccy_code + ", " +
                "rate_refresh_date=" + rate_refresh_date + ",rate_ticker_desc=" + rate_ticker_desc + ", " +
                "create_ts=" + create_ts + ", created_by=" + created_by + "]";
    }
}
