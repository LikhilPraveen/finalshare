package com.indexrates.Controller;

import com.indexrates.Exception.ResourceNotFoundException;
import com.indexrates.Model.IndexRates;
import com.indexrates.Repository.Bloomberg;
import com.indexrates.Repository.Dowjones;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * The type Controller.
 *
 * @author Praveen kumar
 */

@RestController
@RequestMapping(path = "/v1/market-data/index-rates")
public class IndexRateController extends AbstractRestHandler {

    @Autowired
    private Bloomberg bloomberg;

    @Autowired
    private Dowjones dowjones;

    /**
     *
     * @return
     */
    @RequestMapping(value = "/bloomberg/latest/full-load",
            method = RequestMethod.GET,
            produces = {"application/json", "application/xml"})
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Get a complete full_load for bloomberg", notes = "Full_load  for bloomberg.")
    public
    @ResponseBody
    List<IndexRates> getAllFullLoad() {
        return bloomberg.findAll();
    }

    /**
     *
     * @return
     */
    @RequestMapping(value = "/bloomberg/latest/delta-load",
            method = RequestMethod.GET,
            produces = {"application/json", "application/xml"})
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Get a complete delta_load for bloomberg", notes = "delta_load  for bloomberg.")
    public
    @ResponseBody
    List<IndexRates> getAllDeltaLoad() {
        return bloomberg.findAll();
    }

    /**
     *
     * @return
     */
    @RequestMapping(value = "/dow-jones/latest/eod-rate-load",
            method = RequestMethod.GET,
            produces = {"application/json", "application/xml"})
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Get a complete eod-rate-load for dow-jones", notes = "eod-rate-load  for dow-jones.")
    public
    @ResponseBody
    List<IndexRates> getEodRateLoad()
    {
        return dowjones.findAll();
    }

    /**
     *
     * @param tickerId
     * @return
     * @throws ResourceNotFoundException
     */
    @RequestMapping(value = "/bloomberg/latest/get-rates",
            method = RequestMethod.GET,
            produces = {"application/json", "application/xml"})
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Get a single Index-Rates for Bloomberg", notes = "You have to provide a valid tickerID.")
    public
    @ResponseBody
    IndexRates getBloombergRates(@ApiParam(value = "The ID of the Index-Rates.", required = true)
                                 @RequestParam String tickerId,
                                 HttpServletRequest request, HttpServletResponse response)
            throws ResourceNotFoundException {

        IndexRates indexRates = bloomberg.tickerId(tickerId);
        checkResourceFound(indexRates);
        return indexRates;
    }

    /**
     *
     * @param tickerId
     * @return
     * @throws ResourceNotFoundException
     */
    @RequestMapping(value = "/dow-jones/latest/get-rates",
            method = RequestMethod.GET,
            produces = {"application/json", "application/xml"})
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Get a single Index-Rates for Dow-jones", notes = "You have to provide a valid tickerID.")
    public
    @ResponseBody
    IndexRates getDowjonesRates(@ApiParam(value = "The ID of the Index-Rates.", required = true)
                                                @RequestParam String tickerId,
    HttpServletRequest request, HttpServletResponse response)
            throws ResourceNotFoundException {
        IndexRates indexRates = dowjones.tickerId(tickerId);
        checkResourceFound(indexRates);
        return indexRates;
    }
}
